﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookNest_Services.Interface
{
    internal interface IUserBooksService
    {
    }
}
