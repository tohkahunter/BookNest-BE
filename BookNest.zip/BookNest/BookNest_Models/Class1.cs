﻿namespace BookNest_Models;

public class Class1
{

}
