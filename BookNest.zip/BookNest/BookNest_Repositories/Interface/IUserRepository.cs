using BookNest_Repositories.Models;

namespace BookNest_Repositories.Interface
{
    public interface IUserRepository : IGenericRepository<User>
    {
    }
} 